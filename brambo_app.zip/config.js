// Single place for the TMDB key. Used by every page.
window.BRAMBO_CONFIG = { apiKey: "", apiType: "v3" }; // apiType: "v3" or "read-token"
