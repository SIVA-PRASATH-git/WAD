# Brambo — Pure Live API TMDB Web Series Tracker

Brambo is a web series discovery web app configured to work exclusively with live TMDB (The Movie Database) API data.

## API Key Required Notice
All static mock data, placeholder series descriptions, and fallback posters have been removed. 
The app runs **only** when a valid TMDB API key is provided.

### Setup Instructions:
1. Open `config.js` and set `apiKey` to your TMDB key (shared by every page).
2. Serve the folder (e.g. `npx serve`) and open `index.html` in your web browser (or via Live Server).

## Top Rated Feature Block Features
- Designed after clean showcase feature blocks with card styling, posters, star rating pills, caps titles, and overview excerpts.
- Displays 6 top-rated series fetched dynamically from TMDB on every page load.
- Displays 3 items per page with arrow button toggling.
- Generates new random top-rated series combinations on every refresh.

## App pages
`auth.html` (login/signup with scrolling TMDB poster wall), `home.html`, `reviews.html`, `editors.html`, `profile.html`.
Accounts and activity are stored in the browser (localStorage) and the friends feed is simulated. Replace with a backend before production.
